from datetime import datetime, time
from typing import TYPE_CHECKING

# Импортируем ВСЁ нужное из SQLAlchemy
from sqlalchemy import String, Integer, DateTime, ForeignKey, func, Time, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from fitness.app.core.database import Base

if TYPE_CHECKING:
    from app.models.users import User
    from app.models.supplements import Supplement


class UserSupplement(Base):
    __tablename__ = "user_supplements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    supplement_id: Mapped[int] = mapped_column(ForeignKey("supplements.id"), nullable=False)

    dosage: Mapped[str | None] = mapped_column(String(50), nullable=True)
    frequency: Mapped[str | None] = mapped_column(String(50), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    notes: Mapped[str | None] = mapped_column(String(255), nullable=True)

    user: Mapped["User"] = relationship(back_populates="supplements")
    supplement: Mapped["Supplement"] = relationship()
    reminder_days: Mapped[str | None] = mapped_column(String(20), nullable=True)  # "mon,wed,fri"
    reminder_time: Mapped[time | None] = mapped_column(Time, nullable=True)  # 16:00:00
    reminder_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
