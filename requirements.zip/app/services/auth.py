from app.reposytory import refresh_token
from app.models.refresh_token import RefreshToken 
from app.schemas.refresh_token import auth as reposytory_auth
def create_access_token(db: Session, token: Token) -> RefreshToken:
    db_token = reposytory_auth.create_refresh_token(db=db, jti=jti, user_id=user_id, expires_at=expires_at)
    return db_token
